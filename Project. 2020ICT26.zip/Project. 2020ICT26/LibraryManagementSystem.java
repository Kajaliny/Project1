abstract class LibraryItem {
    private String title;
    private String itemID;
    private boolean checkedOut;

    public LibraryItem(String title, String itemID) {
        this.title = title;
        this.itemID = itemID;
        this.checkedOut = false;
    }

    public void checkOut() {
        if (!checkedOut) {
            checkedOut = true;
            System.out.println(title + " checked out successfully.");
        } else {
            System.out.println(title + " is already checked out.");
        }
    }

    public void checkIn() {
        if (checkedOut) {
            checkedOut = false;
            System.out.println(title + " checked in successfully.");
        } else {
            System.out.println(title + " is already checked in.");
        }
    }

    public void displayItemDetails() {
        System.out.println("Title: " + title);
        System.out.println("Item ID: " + itemID);
        System.out.println("Status: " + (checkedOut ? "Checked out" : "Checked in"));
    }
}

class Book extends LibraryItem {
    private String author;
    private int numPages;

    public Book(String title, String itemID, String author, int numPages) {
        super(title, itemID);
        this.author = author;
        this.numPages = numPages;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void displayItemDetails() {
        super.displayItemDetails();
        System.out.println("Author: " + author);
        System.out.println("Number of Pages: " + numPages);
    }
}

class Magazine extends LibraryItem {
    private String issueDate;
    private String publisher;

    public Magazine(String title, String itemID, String issueDate, String publisher) {
        super(title, itemID);
        this.issueDate = issueDate;
        this.publisher = publisher;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public void displayItemDetails() {
        super.displayItemDetails();
        System.out.println("Issue Date: " + issueDate);
        System.out.println("Publisher: " + publisher);
    }
}

class LibraryMember {
    private String memberID;
    private String name;

    public LibraryMember(String memberID, String name) {
        this.memberID = memberID;
        this.name = name;
    }

    public void displayMemberDetails() {
        System.out.println("Member ID: " + memberID);
        System.out.println("Name: " + name);
    }
}

public class LibraryManagementSystem {
    public static void main(String[] args) {
        // Create 5 objects of the Book class
         Book[] books = new Book[5];
        books[0] = new Book("The Catcher in the Rye", "B001", "J.D.Salinger", 240);
        books[1] = new Book("To kill a Mockingbird", "B002", "Harper Lee", 281);
        books[2] = new Book("1984 ", "B003", "George Orwell", 328);
        books[3] = new Book("Pride and Prejudice", "B004", "Jane Austen", 432);
        books[4] = new Book("The Hobbit", "B005", "J.R.R.Tolkien", 320);

        // Create 5 objects of the Magazine class
        Magazine[] magazines = new Magazine[5];
        magazines[0] = new Magazine("National Geographic", "M001", "August 2023", "National Geographic Society");
        magazines[1] = new Magazine("Time", "M002", "September 2023", "Time USA, LLC");
        magazines[2] = new Magazine("Forbes", "M003", "June 2023", "Forbes Media");
        magazines[3] = new Magazine("Vogue", "M004", "July 2023", "Condé Nast");
        magazines[4] = new Magazine("Sports Illustated", "M005", "July 2023", "Maven Coalition");

        // Create 5 objects of the LibraryMember class
        LibraryMember[] members = new LibraryMember[5];
        members[0] = new LibraryMember("L001", "John Doe");
        members[1] = new LibraryMember("L002", "Jane Smith");
        members[2] = new LibraryMember("L003", "David Johnson");
        members[3] = new LibraryMember("L004", "Sarah Wilson");
        members[4] = new LibraryMember("L005", "Michael Brown"); 

        // Set properties of the objects using appropriate setter methods
        books[0].setAuthor("J.D.Salinge");
        books[1].setAuthor("Harper Lee");
        books[2].setAuthor("George Orwell");
        books[3].setAuthor("Jane Austen");
        books[4].setAuthor("J.R.R.Tolkien");

        // Call the checkOut() and checkIn() methods on one of the library items
        books[0].checkOut();
        books[0].checkIn();

        // Display the details of all the library items and library members
        System.out.println("Library Items:");
        for (LibraryItem item : books) {
            item.displayItemDetails();
            System.out.println();
        }
        for (LibraryItem item : magazines) {
            item.displayItemDetails();
            System.out.println();
        }

        System.out.println("Library Members:");
        for (LibraryMember member : members) {
            member.displayMemberDetails();
            System.out.println();
        }
    }
}


/*  out put

The Catcher in the Rye checked out successfully.
The Catcher in the Rye checked in successfully.
Library Items:
Title: The Catcher in the Rye
Item ID: B001
Status: Checked in
Author: J.D.Salinge
Number of Pages: 240

Title: To kill a Mockingbird
Item ID: B002
Status: Checked in
Author: Harper Lee
Number of Pages: 281

Title: 1984
Item ID: B003
Status: Checked in
Author: George Orwell
Number of Pages: 328

Title: Pride and Prejudice
Item ID: B004
Status: Checked in
Author: Jane Austen
Number of Pages: 432

Title: The Hobbit
Item ID: B005
Status: Checked in
Author: J.R.R.Tolkien
Number of Pages: 320

Title: National Geographic
Item ID: M001
Status: Checked in
Issue Date: August 2023
Publisher: National Geographic Society

Title: Time
Item ID: M002
Status: Checked in
Issue Date: September 2023
Publisher: Time USA, LLC

Title: Forbes
Item ID: M003
Status: Checked in
Issue Date: June 2023
Publisher: Forbes Media

Title: Vogue
Item ID: M004
Status: Checked in
Issue Date: July 2023
Publisher: Condé Nast

Title: Sports Illustated
Item ID: M005
Status: Checked in
Issue Date: July 2023
Publisher: Maven Coalition

Library Members:
Member ID: L001
Name: John Doe

Member ID: L002
Name: Jane Smith

Member ID: L003
Name: David Johnson

Member ID: L004
Name: Sarah Wilson

Member ID: L005
Name: Michael Brown
*/





